﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PurchaseManagementSystem.WebApi.Models
{
    public partial class SupplierTable
    {
        public SupplierTable()
        {
            PurchaseTables = new HashSet<PurchaseTable>();
        }

        public string SupplierId { get; set; }
        public string SupplierCompName { get; set; }
        public string ContactPerson { get; set; }
        public string Address { get; set; }
        public decimal? Phone { get; set; }
        public string SupGstno { get; set; }
        public string MailId { get; set; }
        public string PanNumber { get; set; }
        public string Cinnumber { get; set; }
        public string District { get; set; }

        public virtual ICollection<PurchaseTable> PurchaseTables { get; set; }
    }
}
