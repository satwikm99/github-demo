﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace PurchaseManagementSystem.WebApi.Models
{
    public partial class PurchaseDBContext : DbContext
    {
        public PurchaseDBContext()
        {
        }

        public PurchaseDBContext(DbContextOptions<PurchaseDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<PurchaseTable> PurchaseTables { get; set; }
        public virtual DbSet<SupplierTable> SupplierTables { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PurchaseTable>(entity =>
            {
                entity.HasKey(e => e.PurchaseId);

                entity.ToTable("Purchase Table");

                entity.Property(e => e.PurchaseId).HasMaxLength(50);

                entity.Property(e => e.AddedBy).HasMaxLength(50);

                entity.Property(e => e.AddedOn).HasMaxLength(50);

                entity.Property(e => e.Date).HasColumnType("date");

                entity.Property(e => e.Description)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GrandTotal).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.LastUpdated).HasMaxLength(50);

                entity.Property(e => e.PurchaseDate).HasColumnType("datetime");

                entity.Property(e => e.SupplierId)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsFixedLength(true);

                entity.Property(e => e.Vendorcode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Supplier)
                    .WithMany(p => p.PurchaseTables)
                    .HasForeignKey(d => d.SupplierId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Purchase Table_Supplier Table");
            });

            modelBuilder.Entity<SupplierTable>(entity =>
            {
                entity.HasKey(e => e.SupplierId);

                entity.ToTable("Supplier Table");

                entity.Property(e => e.SupplierId)
                    .HasMaxLength(10)
                    .IsFixedLength(true);

                entity.Property(e => e.Address).HasMaxLength(50);

                entity.Property(e => e.Cinnumber)
                    .HasMaxLength(50)
                    .HasColumnName("CINNumber");

                entity.Property(e => e.ContactPerson).HasMaxLength(50);

                entity.Property(e => e.District).HasMaxLength(50);

                entity.Property(e => e.MailId).HasMaxLength(50);

                entity.Property(e => e.PanNumber).HasMaxLength(50);

                entity.Property(e => e.Phone).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.SupGstno)
                    .HasMaxLength(50)
                    .HasColumnName("SupGSTNo");

                entity.Property(e => e.SupplierCompName).HasMaxLength(50);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
