﻿using PurchaseManagementSystem.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PurchaseManagementSystem.WebApi.Repositories
{
    public interface IPurchaseRepository
    {
        Task AddPurchaseDetailsAsync(PurchaseTable purchase);
        Task<bool> UpdatePurchaseDetailsAsync(string purchaseId, PurchaseTable purchase);
        Task<bool> DeleteBookAsync(string purchaseId);
        Task<IEnumerable<PurchaseTable>> GetAllPurchaseDetailsAsync();
        Task<PurchaseTable> GetPurchaseDetailsByIDAsync(string purchaseId);
    }
}
